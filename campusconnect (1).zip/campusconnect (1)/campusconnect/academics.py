"""Module 2: departments, subjects, enrollment and attendance.
All attendance numbers are calculated from AttendanceRecord rows. Nothing is hardcoded."""
import csv
import io
from datetime import date, timedelta

from flask import Response, g, request
from sqlalchemy import case, func

from models import (AttendanceRecord, College, Department, Enrollment, StudentProfile, Subject, User, db)


def summarize(attended, conducted, threshold):
    """Deterministic attendance maths (integers only, no AI)."""
    pct = round(100 * attended / conducted, 1) if conducted else None
    out = {"conducted": conducted, "attended": attended, "missed": conducted - attended, "percentage": pct,
           "below_threshold": pct is not None and 100 * attended < threshold * conducted,
           "classes_needed": 0, "can_miss": 0}
    if conducted:
        if out["below_threshold"]:  # smallest x with (a+x)/(c+x) >= T/100
            num, den = threshold * conducted - 100 * attended, 100 - threshold
            out["classes_needed"] = -(-num // den)
        else:
            out["can_miss"] = (100 * attended) // threshold - conducted
    return out


PRESENT = func.sum(case((AttendanceRecord.present.is_(True), 1), else_=0))


def attendance_snapshot(uid, cid, th):
    """Per-subject attendance for one student -> (rows, total_conducted, total_attended)."""
    subs = Subject.query.join(Enrollment, Enrollment.subject_id == Subject.id).filter(
        Enrollment.student_id == uid, Subject.college_id == cid).order_by(Subject.code).all()
    counts = {r[0]: (r[1], int(r[2] or 0)) for r in db.session.query(
        AttendanceRecord.subject_id, func.count(AttendanceRecord.id), PRESENT).filter_by(
        student_id=uid, college_id=cid).group_by(AttendanceRecord.subject_id)}
    rows, tc, ta = [], 0, 0
    for s in subs:
        c, a = counts.get(s.id, (0, 0))
        tc, ta = tc + c, ta + a
        rows.append({"subject_id": s.id, "code": s.code, "name": s.name,
                     "faculty": s.faculty.name if s.faculty else None, **summarize(a, c, th)})
    return rows, tc, ta


def to_int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def safe_cell(s):  # stops spreadsheet formula injection in CSV exports
    s = str(s)
    return "'" + s if s[:1] in "=+-@" else s


def register(app, ok, fail, require, body, text):
    TH = lambda: int(app.config.get("ATTENDANCE_THRESHOLD", 75))

    def own_subject(sid, allow_admin=True):
        """Subject in MY college; faculty only their own subjects."""
        s = Subject.query.filter_by(id=to_int(sid), college_id=g.user.college_id).first()
        if not s or (g.user.role == "faculty" and s.faculty_id != g.user.id):
            return None
        return s

    # ----- Setup (college admin) -----
    @app.get("/api/departments")
    @require("college_admin", "faculty", "student", "placement_officer")
    def list_departments():
        rows = Department.query.filter_by(college_id=g.user.college_id).order_by(Department.name).all()
        return ok([d.to_dict() for d in rows])

    @app.post("/api/departments")
    @require("college_admin")
    def add_department():
        d = body()
        name, code = text(d, "name", 120), text(d, "code", 20).upper()
        if not name or not code:
            return fail("Department name and code are required.")
        if Department.query.filter_by(college_id=g.user.college_id, code=code).first():
            return fail("That department code already exists.", 409)
        dep = Department(college_id=g.user.college_id, name=name, code=code)
        db.session.add(dep)
        db.session.commit()
        return ok(dep.to_dict(), f"Department {code} added.", 201)

    @app.get("/api/subjects")
    @require("college_admin", "faculty", "student")
    def list_subjects():
        q = Subject.query.filter_by(college_id=g.user.college_id)
        if g.user.role == "faculty":
            q = q.filter_by(faculty_id=g.user.id)
        elif g.user.role == "student":
            q = q.join(Enrollment, Enrollment.subject_id == Subject.id).filter(Enrollment.student_id == g.user.id)
        return ok([s.to_dict() for s in q.order_by(Subject.semester, Subject.code).all()])

    @app.post("/api/subjects")
    @require("college_admin")
    def add_subject():
        d, cid = body(), g.user.college_id
        code, name = text(d, "code", 20).upper(), text(d, "name", 120)
        credits, sem = to_int(d.get("credits")), to_int(d.get("semester"))
        dep = Department.query.filter_by(id=to_int(d.get("department_id")), college_id=cid).first()
        fid = to_int(d.get("faculty_id"))
        fac = User.query.filter_by(id=fid, college_id=cid, role="faculty").first() if fid else None
        if not code or not name or not dep:
            return fail("Subject code, name and department are required.")
        if not credits or not 1 <= credits <= 10 or not sem or not 1 <= sem <= 12:
            return fail("Credits must be 1-10 and semester 1-12.")
        if fid and not fac:
            return fail("Choose a faculty member from your college.")
        if Subject.query.filter_by(college_id=cid, code=code).first():
            return fail("That subject code already exists.", 409)
        s = Subject(college_id=cid, department_id=dep.id, code=code, name=name, credits=credits, semester=sem,
                    faculty_id=fac.id if fac else None)
        db.session.add(s)
        db.session.commit()
        return ok(s.to_dict(), f"Subject {code} added.", 201)

    @app.post("/api/students/enroll")
    @require("college_admin")
    def enroll_student():
        d, cid = body(), g.user.college_id
        st = User.query.filter_by(id=to_int(d.get("student_id")), college_id=cid, role="student").first()
        dep = Department.query.filter_by(id=to_int(d.get("department_id")), college_id=cid).first()
        sem = to_int(d.get("semester"))
        if not st or not dep or not sem or not 1 <= sem <= 12:
            return fail("Choose a student, department and semester (1-12).")
        prof = StudentProfile.query.filter_by(user_id=st.id).first()
        if prof:
            prof.department_id, prof.semester = dep.id, sem
        else:
            db.session.add(StudentProfile(user_id=st.id, college_id=cid, department_id=dep.id, semester=sem))
        have = {e.subject_id for e in Enrollment.query.filter_by(student_id=st.id)}
        added = 0
        for s in Subject.query.filter_by(college_id=cid, department_id=dep.id, semester=sem):
            if s.id not in have:
                db.session.add(Enrollment(college_id=cid, student_id=st.id, subject_id=s.id))
                added += 1
        db.session.commit()
        return ok({"enrolled_in": added}, f"{st.name} is in {dep.code}, semester {sem} ({added} new subjects).")

    # ----- Faculty: roster + marking -----
    @app.get("/api/subjects/<int:sid>/students")
    @require("faculty", "college_admin")
    def roster(sid):
        s = own_subject(sid)
        if not s:
            return fail("Subject not found.", 404)
        try:
            day = date.fromisoformat(request.args.get("date", ""))
        except ValueError:
            day = None
        marked = {r.student_id: r.present for r in AttendanceRecord.query.filter_by(subject_id=s.id, date=day)} if day else {}
        rows = (User.query.join(Enrollment, Enrollment.student_id == User.id)
                .filter(Enrollment.subject_id == s.id, User.college_id == g.user.college_id, User.is_active.is_(True))
                .order_by(User.name).all())
        return ok({"subject": s.to_dict(), "students": [
            {"id": u.id, "name": u.name, "email": u.email, "present": marked.get(u.id)} for u in rows]})

    @app.post("/api/attendance")
    @require("faculty", "college_admin")
    def mark_attendance():
        d = body()
        s = own_subject(d.get("subject_id"))
        if not s:
            return fail("Subject not found.", 404)
        try:
            day = date.fromisoformat(str(d.get("date")))
        except ValueError:
            return fail("Choose a valid date.")
        if day > date.today():
            return fail("You cannot mark attendance for a future date.")
        recs = d.get("records")
        if not isinstance(recs, list) or not recs:
            return fail("No students to save.")
        enrolled = {e.student_id for e in Enrollment.query.filter_by(subject_id=s.id)}
        existing = {r.student_id: r for r in AttendanceRecord.query.filter_by(subject_id=s.id, date=day)}
        present = absent = 0
        for r in recs:
            sid = to_int(r.get("student_id")) if isinstance(r, dict) else None
            if sid not in enrolled:
                return fail("One of the students is not enrolled in this subject.")
            val = bool(r.get("present"))
            if sid in existing:  # editing an existing record: no duplicate row
                existing[sid].present, existing[sid].marked_by = val, g.user.id
            else:
                db.session.add(AttendanceRecord(college_id=g.user.college_id, subject_id=s.id, student_id=sid,
                                                date=day, present=val, marked_by=g.user.id))
                existing[sid] = True  # guards repeated ids inside one request
            present += val
            absent += not val
        db.session.commit()
        return ok({"present": present, "absent": absent}, f"Attendance saved for {s.code} on {day.isoformat()}.")

    @app.get("/api/attendance/subject/<int:sid>")
    @require("faculty", "college_admin")
    def subject_report(sid):
        s = own_subject(sid)
        if not s:
            return fail("Subject not found.", 404)
        counts = {r[0]: (r[1], int(r[2] or 0)) for r in db.session.query(
            AttendanceRecord.student_id, func.count(AttendanceRecord.id), PRESENT).filter_by(subject_id=s.id).group_by(AttendanceRecord.student_id)}
        users = User.query.join(Enrollment, Enrollment.student_id == User.id).filter(Enrollment.subject_id == s.id).order_by(User.name).all()
        rows = []
        for u in users:
            c, a = counts.get(u.id, (0, 0))
            rows.append({"student_id": u.id, "name": u.name, **summarize(a, c, TH())})
        return ok({"subject": s.to_dict(), "threshold": TH(), "students": rows,
                   "below_threshold": [r["name"] for r in rows if r["below_threshold"]]})

    # ----- Student: own attendance -----
    @app.get("/api/attendance/me")
    @require("student")
    def my_attendance():
        rows, tc, ta = attendance_snapshot(g.user.id, g.user.college_id, TH())
        recent = (db.session.query(AttendanceRecord, Subject).join(Subject, Subject.id == AttendanceRecord.subject_id)
                  .filter(AttendanceRecord.student_id == g.user.id, AttendanceRecord.college_id == g.user.college_id)
                  .order_by(AttendanceRecord.date.desc()).limit(30).all())
        return ok({"threshold": TH(), "overall": summarize(ta, tc, TH()), "subjects": rows,
                   "recent": [{"date": r.date.isoformat(), "subject": s.code, "present": r.present} for r, s in recent]})

    # ----- College admin: reports + export -----
    def report_rows():
        """One row per student per subject, filtered. Always limited to the admin's own college."""
        q = (db.session.query(User, Subject, func.count(AttendanceRecord.id), PRESENT)
             .join(Enrollment, Enrollment.student_id == User.id).join(Subject, Subject.id == Enrollment.subject_id)
             .outerjoin(AttendanceRecord, (AttendanceRecord.student_id == User.id) & (AttendanceRecord.subject_id == Subject.id))
             .filter(Subject.college_id == g.user.college_id, User.college_id == g.user.college_id))
        for arg, col in (("subject_id", Subject.id), ("department_id", Subject.department_id), ("semester", Subject.semester)):
            v = to_int(request.args.get(arg))
            if v:
                q = q.filter(col == v)
        return q.group_by(User.id, Subject.id).order_by(Subject.code, User.name).all()

    @app.get("/api/attendance/report")
    @require("college_admin")
    def admin_report():
        by_sub, by_dep = {}, {}
        for u, s, c, a in report_rows():
            a = int(a or 0)
            for bucket, key in ((by_sub, s.id), (by_dep, s.department_id)):
                t = bucket.setdefault(key, [0, 0, 0])
                t[0] += c; t[1] += a
            if c and 100 * a < TH() * c:
                by_sub[s.id][2] += 1
        subs = {s.id: s for s in Subject.query.filter_by(college_id=g.user.college_id)}
        deps = {d.id: d for d in Department.query.filter_by(college_id=g.user.college_id)}
        return ok({"threshold": TH(),
                   "departments": [{"department": deps[k].name, **summarize(v[1], v[0], TH())} for k, v in by_dep.items()],
                   "subjects": [{"code": subs[k].code, "name": subs[k].name, "semester": subs[k].semester,
                                 "faculty": subs[k].faculty.name if subs[k].faculty else None,
                                 "students_below": v[2], **summarize(v[1], v[0], TH())} for k, v in by_sub.items()]})

    @app.get("/api/attendance/export.csv")
    @require("college_admin")
    def export_csv():
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Student", "Email", "Subject code", "Subject", "Semester", "Conducted", "Attended", "Percentage"])
        for u, s, c, a in report_rows():
            a = int(a or 0)
            w.writerow([safe_cell(u.name), safe_cell(u.email), s.code, safe_cell(s.name), s.semester, c, a,
                        summarize(a, c, TH())["percentage"] or ""])
        return Response(buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": "attachment; filename=attendance_report.csv"})


def seed_academics():
    """Fictional sample timetable data for the demo colleges (only if none exists yet)."""
    for c in College.query.filter_by(is_demo=True).all():
        if Department.query.filter_by(college_id=c.id).first():
            continue
        dep = Department(college_id=c.id, name="Computer Science (sample)", code="CSE")
        db.session.add(dep)
        fac = User.query.filter_by(college_id=c.id, role="faculty").first()
        db.session.flush()
        subs = [Subject(college_id=c.id, department_id=dep.id, code=code, name=name, credits=cr, semester=3,
                        faculty_id=fac.id if fac else None)
                for code, name, cr in (("CS101", "Programming in Python", 4), ("CS102", "Database Systems", 3),
                                       ("CS103", "Computer Networks", 3))]
        db.session.add_all(subs)
        first = User.query.filter_by(college_id=c.id, role="student").first()
        dom = first.email.split("@")[1]
        students = [first]
        for i, nm in enumerate(("Sample Student B", "Sample Student C"), start=2):
            u = User(college_id=c.id, name=nm, email=f"student{i}@{dom}", role="student")
            u.set_password("Demo@12345")
            db.session.add(u)
            students.append(u)
        db.session.flush()
        days, d = [], date.today()
        while len(days) < 10:
            d -= timedelta(days=1)
            if d.weekday() < 5:
                days.append(d)
        for i, st in enumerate(students):
            db.session.add(StudentProfile(user_id=st.id, college_id=c.id, department_id=dep.id, semester=3))
            for j, sub in enumerate(subs):
                db.session.add(Enrollment(college_id=c.id, student_id=st.id, subject_id=sub.id))
                for k, day in enumerate(days):
                    db.session.add(AttendanceRecord(college_id=c.id, subject_id=sub.id, student_id=st.id, date=day,
                                                    present=(k * 7 + i * 3 + j * 5) % 10 >= 2 + i * 2, marked_by=fac.id))
    db.session.commit()
