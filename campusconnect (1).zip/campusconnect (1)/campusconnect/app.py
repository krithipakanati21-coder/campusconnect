"""CampusConnect - Module 1: Flask app, auth, roles, multi-college (tenant) isolation.
Run:  python app.py
"""
import os
import re
from functools import wraps

from flask import Flask, g, jsonify, redirect, render_template, request, session
from werkzeug.exceptions import HTTPException

import academics
import chatbot
from models import ROLES, Announcement, College, User, db

COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
CREATABLE_ROLES = ("student", "faculty", "placement_officer", "recruiter", "college_admin")
CAN_POST = ("college_admin", "faculty", "placement_officer")
CATEGORIES = ("general", "academic", "event", "placement", "administrative")


# ---------- JSON helpers: every API returns {"success", "data", "message"} ----------
def ok(data=None, message="", status=200):
    return jsonify({"success": True, "data": data, "message": message}), status


def fail(message, status=400):
    return jsonify({"success": False, "data": None, "message": message}), status


def body():
    return request.get_json(silent=True) or {}


def text(data, key, maxlen=200):
    return str(data.get(key) or "").strip()[:maxlen]


# ---------- Auth decorator: login check + role check ----------
def require(*roles):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            uid = session.get("uid")
            user = db.session.get(User, uid) if uid else None
            if not user or not user.is_active or (user.college and not user.college.is_active):
                session.clear()
                return fail("Please log in to continue.", 401)
            if roles and user.role not in roles:
                return fail("You do not have permission for this action.", 403)
            g.user = user
            return fn(*a, **kw)
        return wrapper
    return deco


def create_app(overrides=None):
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY", "dev-only-change-me"),
        SQLALCHEMY_DATABASE_URI=os.environ.get("DATABASE_URL", "sqlite:///campusconnect.db"),
        ATTENDANCE_THRESHOLD=int(os.environ.get("ATTENDANCE_THRESHOLD", 75)),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
    )
    if overrides:
        app.config.update(overrides)
    db.init_app(app)
    with app.app_context():
        db.create_all()
        seed_demo_data()
        academics.seed_academics()

    # ----- Pages -----
    @app.get("/")
    def home():
        return redirect("/dashboard" if session.get("uid") else "/login")

    @app.get("/login")
    def login_page():
        return render_template("login.html")

    @app.get("/dashboard")
    def dashboard_page():
        if not session.get("uid"):
            return redirect("/login")
        return render_template("dashboard.html")

    # ----- Auth API -----
    @app.post("/api/auth/login")
    def login():
        d = body()
        code, email, pw = text(d, "college_code", 20).upper(), text(d, "email", 160).lower(), d.get("password") or ""
        if not email or not pw:
            return fail("Enter your email and password.")
        if code:
            college = College.query.filter_by(code=code, is_active=True).first()
            user = User.query.filter_by(college_id=college.id, email=email).first() if college else None
        else:  # empty college code = platform administrator
            user = User.query.filter_by(college_id=None, email=email).first()
        if not user or not user.is_active or not user.check_password(pw):
            return fail("Incorrect college code, email, or password.", 401)
        session.clear()
        session["uid"] = user.id
        session.permanent = False
        return ok(user.to_dict(), "Logged in.")

    @app.post("/api/auth/logout")
    def logout():
        session.clear()
        return ok(message="Logged out.")

    @app.get("/api/auth/me")
    @require()
    def me():
        return ok(g.user.to_dict())

    # ----- Dashboard summary (role-specific) -----
    @app.get("/api/dashboard")
    @require()
    def dashboard():
        u = g.user
        if u.role == "platform_admin":
            return ok({"colleges": College.query.count(), "users": User.query.count()})
        cid = u.college_id  # tenant filter
        data = {"announcements": Announcement.query.filter_by(college_id=cid).count()}
        if u.role == "college_admin":
            for role in ("student", "faculty", "placement_officer", "recruiter"):
                data[role + "s"] = User.query.filter_by(college_id=cid, role=role).count()
        latest = Announcement.query.filter_by(college_id=cid).order_by(Announcement.created_at.desc()).limit(3).all()
        data["latest"] = [a.to_dict() for a in latest]
        return ok(data)

    # ----- Colleges (platform admin only) -----
    @app.get("/api/colleges")
    @require("platform_admin")
    def list_colleges():
        rows = College.query.order_by(College.created_at.desc()).all()
        return ok([c.to_dict() | {"users": User.query.filter_by(college_id=c.id).count()} for c in rows])

    @app.post("/api/colleges")
    @require("platform_admin")
    def create_college():
        d = body()
        name, code = text(d, "name", 120), re.sub(r"[^A-Z0-9]", "", text(d, "code", 20).upper())
        color = text(d, "primary_color", 7) or "#3b4cca"
        a_name, a_email, a_pw = text(d, "admin_name", 120), text(d, "admin_email", 160).lower(), d.get("admin_password") or ""
        if not name or not code:
            return fail("College name and code are required.")
        if not COLOR_RE.match(color):
            return fail("Color must look like #3b4cca.")
        if not a_name or not EMAIL_RE.match(a_email) or len(a_pw) < 8:
            return fail("Admin name, a valid admin email, and a password of 8+ characters are required.")
        if College.query.filter_by(code=code).first():
            return fail("That college code is already taken.", 409)
        college = College(name=name, code=code, primary_color=color)
        db.session.add(college)
        db.session.flush()
        admin = User(college_id=college.id, name=a_name, email=a_email, role="college_admin")
        admin.set_password(a_pw)
        db.session.add(admin)
        db.session.commit()
        return ok(college.to_dict(), f"College {code} created.", 201)

    # ----- Users (college admin, own college only) -----
    @app.get("/api/users")
    @require("college_admin")
    def list_users():
        q = User.query.filter_by(college_id=g.user.college_id)
        role = request.args.get("role")
        if role in ROLES:
            q = q.filter_by(role=role)
        return ok([u.to_dict() for u in q.order_by(User.created_at.desc()).limit(500).all()])

    @app.post("/api/users")
    @require("college_admin")
    def create_user():
        d = body()
        name, email, role, pw = text(d, "name", 120), text(d, "email", 160).lower(), text(d, "role", 30), d.get("password") or ""
        if not name or not EMAIL_RE.match(email):
            return fail("Enter a name and a valid email.")
        if role not in CREATABLE_ROLES:
            return fail("Choose a valid role.")
        if len(pw) < 8:
            return fail("Password must be at least 8 characters.")
        if User.query.filter_by(college_id=g.user.college_id, email=email).first():
            return fail("A user with that email already exists in your college.", 409)
        user = User(college_id=g.user.college_id, name=name, email=email, role=role)
        user.set_password(pw)
        db.session.add(user)
        db.session.commit()
        return ok(user.to_dict(), f"{name} added.", 201)

    @app.post("/api/users/<int:uid>/toggle")
    @require("college_admin")
    def toggle_user(uid):
        user = User.query.filter_by(id=uid, college_id=g.user.college_id).first()  # tenant filter
        if not user:
            return fail("User not found.", 404)
        if user.id == g.user.id:
            return fail("You cannot deactivate your own account.")
        user.is_active = not user.is_active
        db.session.commit()
        return ok(user.to_dict(), "User activated." if user.is_active else "User deactivated.")

    # ----- Announcements (tenant-scoped) -----
    @app.get("/api/announcements")
    @require("college_admin", "faculty", "placement_officer", "student", "recruiter")
    def list_announcements():
        q = Announcement.query.filter_by(college_id=g.user.college_id)
        cat = request.args.get("category")
        if cat in CATEGORIES:
            q = q.filter_by(category=cat)
        return ok([a.to_dict() for a in q.order_by(Announcement.created_at.desc()).limit(100).all()])

    @app.post("/api/announcements")
    @require(*CAN_POST)
    def create_announcement():
        d = body()
        title, content, cat = text(d, "title", 150), text(d, "body", 5000), text(d, "category", 30) or "general"
        if not title or not content:
            return fail("Title and message are required.")
        if cat not in CATEGORIES:
            return fail("Choose a valid category.")
        a = Announcement(college_id=g.user.college_id, author_id=g.user.id, title=title, body=content, category=cat)
        db.session.add(a)
        db.session.commit()
        return ok(a.to_dict(), "Published.", 201)

    @app.delete("/api/announcements/<int:aid>")
    @require(*CAN_POST)
    def delete_announcement(aid):
        a = Announcement.query.filter_by(id=aid, college_id=g.user.college_id).first()  # tenant filter
        if not a:
            return fail("Announcement not found.", 404)
        if g.user.role != "college_admin" and a.author_id != g.user.id:
            return fail("You can only delete your own announcements.", 403)
        db.session.delete(a)
        db.session.commit()
        return ok(message="Deleted.")

    academics.register(app, ok, fail, require, body, text)  # Module 2 routes
    chatbot.register(app, ok, fail, require, body, text)  # AI assistant + doubts

    # ----- Errors: JSON for /api, normal pages otherwise -----
    @app.errorhandler(Exception)
    def on_error(e):
        if not request.path.startswith("/api/"):
            if isinstance(e, HTTPException):
                return e
            raise e
        if isinstance(e, HTTPException):
            return fail(e.description, e.code)
        app.logger.exception(e)
        db.session.rollback()
        return fail("Server error. Please try again.", 500)

    return app


def seed_demo_data():
    """Creates fictional sample colleges the first time the app runs."""
    if College.query.first():
        return
    root = User(college_id=None, name="Platform Admin", email="admin@campusconnect.local", role="platform_admin")
    root.set_password("Admin@12345")
    db.session.add(root)
    specs = [
        ("Demo Institute of Technology (sample)", "DEMO", "#3b4cca", "demo.edu"),
        ("Riverside Sample College (sample)", "RIVER", "#7c4dbd", "river.edu"),
    ]
    for name, code, color, dom in specs:
        c = College(name=name, code=code, primary_color=color, is_demo=True)
        db.session.add(c)
        db.session.flush()
        people = [("College Admin", "admin", "college_admin"), ("Dr. Sample Faculty", "faculty", "faculty"),
                  ("Sample Placement Officer", "placement", "placement_officer"), ("Sample Student", "student", "student")]
        users = {}
        for pname, local, role in people:
            u = User(college_id=c.id, name=pname, email=f"{local}@{dom}", role=role)
            u.set_password("Demo@12345")
            db.session.add(u)
            users[role] = u
        db.session.flush()
        db.session.add(Announcement(college_id=c.id, author_id=users["college_admin"].id, category="general",
                                    title=f"Welcome to {code} on CampusConnect",
                                    body="This is sample data. Faculty, placement officers, and admins can publish announcements here."))
        db.session.add(Announcement(college_id=c.id, author_id=users["placement_officer"].id, category="placement",
                                    title="Placement season briefing (sample)",
                                    body="Sample announcement. Recruitment features arrive in a later module."))
    db.session.commit()


if __name__ == "__main__":
    create_app().run(host="0.0.0.0", port=5000, debug=True)
