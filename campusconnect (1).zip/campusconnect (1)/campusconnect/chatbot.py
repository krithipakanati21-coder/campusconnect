"""AI assistant (local engine, no API key needed).
How it understands people: it lowercases, fixes typos by fuzzy matching (difflib), maps slang/short forms
(dbms -> database), scores each intent, finds which of the student's own subjects is meant, and remembers the
last intent/subject for follow-ups ("what about databse?"). Answers come ONLY from the database.
If it cannot answer, it finds the faculty who teach the relevant subject and helps the student send a doubt.
To plug in a real LLM later, replace handle() and keep the same JSON output."""
import difflib
import re

from flask import g

from academics import attendance_snapshot, to_int
from models import Announcement, DoubtRequest, Enrollment, Subject, User, db, now

STOP = set("""a an the is are am was i my me mine to of in on for and or do does did what which who whom how when where can
could would should you your please pls tell show about it this that with have has be will get give want need know any some
kya hai hain mera meri mujhe kitna kitni ka ki ke se me bata batao""".split())
ALIASES = {"dbms": "database", "db": "database", "sql": "database", "cn": "networks", "network": "networks",
           "networking": "networks", "py": "python", "coding": "programming", "code": "programming"}
INTENTS = {  # order = priority when scores tie
    "attendance": "attendance attend attending attended attendence present absent percentage percent bunk shortage detained".split(),
    "placement": "placement placements job jobs company companies drive drives interview interviews recruit recruiter hiring eligible eligibility internship offer".split(),
    "announcements": "announcement announcements announce announced notice notices circular circulars news".split(),
    "faculty_who": "teacher teachers teaches teaching faculty lecturer professor sir madam staff taught".split(),
    "subjects": "subject subjects course courses credits credit enrolled syllabus".split(),
    "timetable": "timetable schedule class classes lecture lectures period today tomorrow".split(),
    "greeting": "hi hii hello hey namaste hola".split(),
    "thanks": "thanks thank thx thankyou".split(),
    "help": "help features".split(),
}
SUGGEST = ["What's my attendance?", "Which subjects am I enrolled in?", "Latest announcements", "Who teaches my subjects?"]


def toks_of(msg):
    return [ALIASES.get(t, t) for t in re.findall(r"[a-z0-9]+", msg.lower())]


def close(tok, words):
    return tok in words or (len(tok) >= 5 and bool(difflib.get_close_matches(tok, words, n=1, cutoff=0.82)))


def detect_intent(toks):
    best, score = None, 0
    for name, words in INTENTS.items():
        s = sum(1 for t in toks if close(t, words))
        if s > score:
            best, score = name, s
    return best


def find_subject(toks, subjects):
    """Returns (single best subject or None, list of tied candidates)."""
    scored = []
    for s in subjects:
        words = [w for w in re.findall(r"[a-z0-9]+", s.name.lower()) if w not in STOP and len(w) > 2] + [s.code.lower()]
        sc = sum(1 for t in toks if t not in STOP and (t in words or (len(t) >= 4 and difflib.get_close_matches(t, words, n=1, cutoff=0.8))))
        scored.append((sc, s))
    top = max((x[0] for x in scored), default=0)
    if top == 0:
        return None, []
    ties = [s for sc, s in scored if sc == top]
    return (ties[0] if len(ties) == 1 else None), ties


def out(reply, intent, subj_id=None, sources=None, handoff=None, suggestions=None):
    return {"reply": reply, "intent": intent, "sources": sources or [], "handoff": handoff,
            "suggestions": suggestions or [], "context": {"intent": intent, "subject_id": subj_id}}


def handle(user, message, ctx, th):
    toks = toks_of(message)
    meaningful = [t for t in toks if t not in STOP]
    subjects = Subject.query.join(Enrollment, Enrollment.subject_id == Subject.id).filter(
        Enrollment.student_id == user.id, Subject.college_id == user.college_id).order_by(Subject.code).all()
    intent = detect_intent(toks)
    subj, ties = find_subject(toks, subjects)
    short = len(meaningful) <= 3
    # Conversation memory: short follow-ups reuse the previous intent / subject.
    if intent is None and (subj or ties) and ctx.get("intent") in ("attendance", "faculty_who") and short:
        intent = ctx["intent"]
    if intent in ("attendance", "faculty_who") and not subj and not ties and ctx.get("subject_id") and short:
        subj = next((s for s in subjects if s.id == to_int(ctx["subject_id"])), None)
    sid = subj.id if subj else None

    if intent == "greeting" and len(meaningful) <= 1:
        return out(f"Hi {user.name.split()[0]}! I can check your attendance, subjects, faculty and announcements, "
                   "and connect you with the right faculty member for anything I can't answer.", "greeting", suggestions=SUGGEST)
    if intent == "thanks":
        return out("You're welcome! Ask me anything else about your college.", "thanks", suggestions=SUGGEST)
    if intent == "help":
        return out("I can: show your attendance (overall or per subject, and how many classes you need), list your subjects "
                   "and who teaches them, show the latest announcements, and help you send a question to the right faculty.",
                   "help", suggestions=SUGGEST)
    if intent in ("attendance", "faculty_who", "subjects") and not subjects:
        return out("You are not enrolled in any subjects yet. Please ask your college admin to enroll you.", intent)
    if intent in ("attendance", "faculty_who") and ties and not subj:
        names = " or ".join(f"{s.name} ({s.code})" for s in ties)
        return out(f"Which subject do you mean: {names}?", intent, suggestions=[s.code for s in ties])

    if intent == "attendance":
        rows, tc, ta = attendance_snapshot(user.id, user.college_id, th)
        src = ["Your attendance records, marked by faculty"]
        if subj:
            r = next(x for x in rows if x["subject_id"] == subj.id)
            if not r["conducted"]:
                return out(f"No classes have been recorded for {subj.name} yet.", intent, sid, src)
            tip = (f"Attend the next {r['classes_needed']} classes in a row to reach {th}%." if r["below_threshold"]
                   else f"You can miss {r['can_miss']} more class(es) and stay at {th}% or above.")
            return out(f"{subj.name} ({subj.code}): {r['percentage']}% ({r['attended']} of {r['conducted']} classes attended, "
                       f"{r['missed']} missed). The minimum is {th}%. {tip}", intent, sid, src)
        if not tc:
            return out("No attendance has been recorded for you yet.", intent, None, src)
        low = [r for r in rows if r["below_threshold"]]
        pct = round(100 * ta / tc, 1)
        txt = f"Your overall attendance is {pct}% ({ta} of {tc} classes). The minimum is {th}%."
        if low:
            txt += " Below the minimum: " + "; ".join(f"{r['code']} {r['percentage']}% (needs {r['classes_needed']} more classes)" for r in low) + "."
        else:
            txt += " All your subjects are at or above the minimum."
        return out(txt, intent, None, src, suggestions=[f"Attendance in {r['code']}" for r in rows[:3]])

    if intent == "subjects":
        lines = [f"{s.code} · {s.name} · {s.credits} credits · {s.faculty.name if s.faculty else 'faculty not assigned'}" for s in subjects]
        return out("Your subjects:\n" + "\n".join(lines), intent, None, ["Your enrollment records"])

    if intent == "faculty_who":
        shown = [subj] if subj else subjects
        lines = [f"{s.name} ({s.code}): {s.faculty.name} ({s.faculty.email})" if s.faculty else f"{s.name} ({s.code}): not assigned yet" for s in shown]
        return out("\n".join(lines), intent, sid, ["Subject allocation records"])

    if intent == "announcements":
        rows = Announcement.query.filter_by(college_id=user.college_id).order_by(Announcement.created_at.desc()).limit(3).all()
        if not rows:
            return out("There are no announcements yet.", intent)
        return out("Latest announcements:\n" + "\n".join(f"• {a.title} ({a.category}, {a.author.name}, {a.created_at:%d %b})" for a in rows),
                   intent, None, ["College announcements"])

    if intent == "placement":
        po = User.query.filter_by(college_id=user.college_id, role="placement_officer", is_active=True).all()
        who = "; ".join(f"{p.name} ({p.email})" for p in po) or "your college admin"
        return out("Placement drives and eligibility checks are not part of this version yet, so I can't tell you what you qualify for. "
                   f"Please contact: {who}.", intent)

    if intent == "timetable":
        fac = "; ".join(f"{s.code}: {s.faculty.name}" for s in subjects if s.faculty) or "your department"
        return out(f"Timetables are not set up in this version yet. Your faculty can share class timings. {fac}", intent)

    # ---- Not answerable from college data -> hand off to faculty ----
    if len(meaningful) < 2 and not subj:
        return out("Could you tell me a bit more? For example, which subject is this about?", None, suggestions=SUGGEST)
    targets = [subj] if subj else (ties or subjects)
    fac, by = [], {}
    for s in targets:
        if s.faculty_id:
            by.setdefault(s.faculty_id, []).append(s)
    for subs_of in by.values():
        f, first = subs_of[0].faculty, subs_of[0]
        names = ", ".join(f"{x.name} ({x.code})" for x in subs_of)
        fac.append({"id": f.id, "name": f.name, "email": f.email, "subject_id": first.id, "subject": f"{first.name} ({first.code})",
                    "why": f"Teaches {names}, which you are enrolled in."})
    if not fac:
        return out("I can't answer that from your college's records, and I can't find a faculty member assigned to a matching subject. "
                   "Please contact your college admin or department.", None)
    first = fac[0]
    draft = f"Hello,\n\nI have a question about {first['subject']}:\n\n{message.strip()}\n\nThank you,\n{user.name}" if subj else \
            f"Hello,\n\nI have a question:\n\n{message.strip()}\n\nThank you,\n{user.name}"
    why = "" if subj else " I'm not sure which subject this belongs to, so here are the faculty for your subjects."
    return out("I don't have a reliable answer to that in your college's records, and I won't guess." + why +
               " A faculty member can help. Review the message below and send it when you're happy with it. Nothing is sent until you approve.",
               None, sid, handoff={"faculty": fac, "draft": draft})


def doubt_dict_list(q):
    return [d.to_dict() for d in q.order_by(DoubtRequest.created_at.desc()).limit(100).all()]


def register(app, ok, fail, require, body, text):
    @app.post("/api/chat")
    @require("student")
    def chat():
        d = body()
        msg = text(d, "message", 500)
        if not msg:
            return fail("Type a question first.")
        ctx = d.get("context") if isinstance(d.get("context"), dict) else {}
        return ok(handle(g.user, msg, ctx, int(app.config.get("ATTENDANCE_THRESHOLD", 75))))

    @app.post("/api/doubts")
    @require("student")
    def create_doubt():
        d = body()
        q = text(d, "question", 2000)
        sub = Subject.query.filter_by(id=to_int(d.get("subject_id")), college_id=g.user.college_id).first()
        if len(q) < 5:
            return fail("Write your question (at least 5 characters).")
        if not sub or not Enrollment.query.filter_by(student_id=g.user.id, subject_id=sub.id).first():
            return fail("Choose one of your own subjects.")
        if not sub.faculty_id or sub.faculty_id != to_int(d.get("faculty_id")):
            return fail("That faculty member does not teach this subject.")
        r = DoubtRequest(college_id=g.user.college_id, student_id=g.user.id, faculty_id=sub.faculty_id, subject_id=sub.id, question=q)
        db.session.add(r)
        db.session.commit()
        return ok(r.to_dict(), f"Sent to {sub.faculty.name}. Status: open.", 201)

    @app.get("/api/doubts")
    @require("student", "faculty")
    def list_doubts():
        col = DoubtRequest.student_id if g.user.role == "student" else DoubtRequest.faculty_id
        return ok(doubt_dict_list(DoubtRequest.query.filter(DoubtRequest.college_id == g.user.college_id, col == g.user.id)))

    @app.post("/api/doubts/<int:did>/reply")
    @require("faculty")
    def reply_doubt(did):
        r = DoubtRequest.query.filter_by(id=did, college_id=g.user.college_id, faculty_id=g.user.id).first()
        msg = text(body(), "reply", 3000)
        if not r:
            return fail("Doubt not found.", 404)
        if len(msg) < 2:
            return fail("Write a reply first.")
        r.reply, r.status, r.replied_at = msg, "answered", now()
        db.session.commit()
        return ok(r.to_dict(), "Reply sent.")
