"""Database models. Every college-owned table carries a college_id (multi-tenant)."""
from datetime import datetime, timezone
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

ROLES = ("platform_admin", "college_admin", "student", "faculty", "placement_officer", "recruiter")


def now():
    return datetime.now(timezone.utc)


def iso(dt):
    return dt.isoformat() + "Z" if dt else None


class College(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    code = db.Column(db.String(20), unique=True, nullable=False, index=True)
    primary_color = db.Column(db.String(7), default="#3b4cca")
    is_demo = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=now)

    def to_dict(self):
        return {"id": self.id, "name": self.name, "code": self.code,
                "primary_color": self.primary_color, "is_demo": self.is_demo,
                "is_active": self.is_active, "created_at": iso(self.created_at)}


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    college_id = db.Column(db.Integer, db.ForeignKey("college.id"), nullable=True, index=True)  # None = platform admin
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(30), nullable=False, index=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=now)
    college = db.relationship("College")
    __table_args__ = (db.UniqueConstraint("college_id", "email", name="uq_user_college_email"),)

    def set_password(self, raw):
        self.password_hash = generate_password_hash(raw)

    def check_password(self, raw):
        return check_password_hash(self.password_hash, raw)

    def to_dict(self):
        return {"id": self.id, "name": self.name, "email": self.email, "role": self.role,
                "is_active": self.is_active, "college_id": self.college_id,
                "college": self.college.to_dict() if self.college else None,
                "created_at": iso(self.created_at)}


class Announcement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    college_id = db.Column(db.Integer, db.ForeignKey("college.id"), nullable=False, index=True)
    author_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    title = db.Column(db.String(150), nullable=False)
    body = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(30), default="general")
    created_at = db.Column(db.DateTime, default=now, index=True)
    author = db.relationship("User")

    def to_dict(self):
        return {"id": self.id, "title": self.title, "body": self.body, "category": self.category,
                "author": self.author.name if self.author else "", "author_id": self.author_id,
                "created_at": iso(self.created_at)}


# ---------------- Module 2: academics + attendance ----------------
class Department(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    college_id = db.Column(db.Integer, db.ForeignKey("college.id"), nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False)
    code = db.Column(db.String(20), nullable=False)
    __table_args__ = (db.UniqueConstraint("college_id", "code", name="uq_dept_college_code"),)

    def to_dict(self):
        return {"id": self.id, "name": self.name, "code": self.code}


class Subject(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    college_id = db.Column(db.Integer, db.ForeignKey("college.id"), nullable=False, index=True)
    department_id = db.Column(db.Integer, db.ForeignKey("department.id"), nullable=False)
    code = db.Column(db.String(20), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    credits = db.Column(db.Integer, default=3)
    semester = db.Column(db.Integer, default=1)
    faculty_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True, index=True)
    department = db.relationship("Department")
    faculty = db.relationship("User")
    __table_args__ = (db.UniqueConstraint("college_id", "code", name="uq_subject_college_code"),)

    def to_dict(self):
        return {"id": self.id, "code": self.code, "name": self.name, "credits": self.credits, "semester": self.semester,
                "department_id": self.department_id, "department": self.department.code,
                "faculty_id": self.faculty_id, "faculty": self.faculty.name if self.faculty else None}


class StudentProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), unique=True, nullable=False)
    college_id = db.Column(db.Integer, db.ForeignKey("college.id"), nullable=False, index=True)
    department_id = db.Column(db.Integer, db.ForeignKey("department.id"), nullable=False)
    semester = db.Column(db.Integer, default=1)


class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    college_id = db.Column(db.Integer, db.ForeignKey("college.id"), nullable=False, index=True)
    student_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    subject_id = db.Column(db.Integer, db.ForeignKey("subject.id"), nullable=False, index=True)
    __table_args__ = (db.UniqueConstraint("student_id", "subject_id", name="uq_enroll"),)


class AttendanceRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    college_id = db.Column(db.Integer, db.ForeignKey("college.id"), nullable=False, index=True)
    subject_id = db.Column(db.Integer, db.ForeignKey("subject.id"), nullable=False, index=True)
    student_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    date = db.Column(db.Date, nullable=False)
    present = db.Column(db.Boolean, nullable=False)
    marked_by = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    # One record per student, subject and day: duplicates are impossible at database level.
    __table_args__ = (db.UniqueConstraint("subject_id", "student_id", "date", name="uq_attendance"),)


class DoubtRequest(db.Model):
    """A question a student sends to a faculty member (only after the student approves it)."""
    id = db.Column(db.Integer, primary_key=True)
    college_id = db.Column(db.Integer, db.ForeignKey("college.id"), nullable=False, index=True)
    student_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    faculty_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    subject_id = db.Column(db.Integer, db.ForeignKey("subject.id"), nullable=False)
    question = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default="open")  # open -> answered
    reply = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=now)
    replied_at = db.Column(db.DateTime)
    student = db.relationship("User", foreign_keys=[student_id])
    faculty = db.relationship("User", foreign_keys=[faculty_id])
    subject = db.relationship("Subject")

    def to_dict(self):
        return {"id": self.id, "student": self.student.name, "faculty": self.faculty.name, "subject": self.subject.code,
                "question": self.question, "status": self.status, "reply": self.reply,
                "created_at": iso(self.created_at), "replied_at": iso(self.replied_at)}
