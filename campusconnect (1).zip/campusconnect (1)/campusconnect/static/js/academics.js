// Module 2 screens: Academics setup, Attendance (mark / my attendance / reports).
// Loaded BEFORE dashboard.js; it registers its menu items and views in window.EXTRA_NAV / EXTRA_VIEWS.
(function () {
  window.EXTRA_NAV = window.EXTRA_NAV || {};
  window.EXTRA_VIEWS = window.EXTRA_VIEWS || {};
  const nav = (role, items) => { (window.EXTRA_NAV[role] = window.EXTRA_NAV[role] || []).push(...items); };
  nav("college_admin", [["academics", "Academics"], ["reports", "Attendance reports"]]);
  nav("faculty", [["mark", "Mark attendance"]]);
  nav("student", [["myattendance", "My attendance"]]);

  const today = () => new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
  const pct = s => s.percentage === null ? "–" : s.percentage + "%";
  const opts = (arr, f) => arr.map(f).join("");
  const nextStep = (s, th) => !s.conducted ? "No classes recorded yet." : s.below_threshold
    ? `Attend the next ${s.classes_needed} classes in a row to reach ${th}%.` : `You can miss ${s.can_miss} more class(es) and stay at ${th}%.`;
  async function post(url, body, after) {
    try { const r = await api(url, { method: "POST", body }); toast(r.message, "good"); after(); }
    catch (e) { toast(e.message, "err"); }
  }

  async function academics() {
    const [deps, subs, fac, stu] = (await Promise.all(["/api/departments", "/api/subjects", "/api/users?role=faculty", "/api/users?role=student"].map(u => api(u)))).map(r => r.data);
    const depOpts = opts(deps, d => `<option value="${d.id}">${esc(d.code)} · ${esc(d.name)}</option>`);
    $("view").innerHTML = head("Academics", "Set up departments, subjects and enroll students.") +
      `<div class="panel"><h3>Add a department</h3><form id="depForm"><div class="grid2">
        <div class="field"><label for="dName">Name</label><input id="dName" required></div>
        <div class="field"><label for="dCode">Code</label><input id="dCode" maxlength="20" required></div></div>
        <button class="btn" type="submit">Add department</button></form></div>
      <div class="panel"><h3>Add a subject</h3><form id="subForm"><div class="grid2">
        <div class="field"><label for="sCode">Subject code</label><input id="sCode" required></div>
        <div class="field"><label for="sName">Subject name</label><input id="sName" required></div>
        <div class="field"><label for="sCredits">Credits</label><input id="sCredits" type="number" min="1" max="10" value="3"></div>
        <div class="field"><label for="sSemester">Semester</label><input id="sSemester" type="number" min="1" max="12" value="1"></div>
        <div class="field"><label for="sDept">Department</label><select id="sDept">${depOpts}</select></div>
        <div class="field"><label for="sFaculty">Faculty</label><select id="sFaculty"><option value="">Not assigned</option>${opts(fac, f => `<option value="${f.id}">${esc(f.name)}</option>`)}</select></div></div>
        <button class="btn" type="submit">Add subject</button></form></div>
      <div class="panel"><h3>Enroll a student</h3><p class="sub" style="margin-bottom:12px">Puts the student in a department and semester and enrolls them in every subject for it.</p>
        <form id="enrollForm"><div class="grid2">
        <div class="field"><label for="eStudent">Student</label><select id="eStudent">${opts(stu, s => `<option value="${s.id}">${esc(s.name)} (${esc(s.email)})</option>`)}</select></div>
        <div class="field"><label for="eDept">Department</label><select id="eDept">${depOpts}</select></div>
        <div class="field"><label for="eSemester">Semester</label><input id="eSemester" type="number" min="1" max="12" value="1"></div></div>
        <button class="btn" type="submit">Enroll student</button></form></div>
      <div class="panel"><h3>Subjects (${subs.length})</h3><div class="tablewrap"><table><thead><tr><th>Code</th><th>Name</th><th>Dept</th><th>Sem</th><th>Credits</th><th>Faculty</th></tr></thead><tbody>
        ${opts(subs, s => `<tr><td>${esc(s.code)}</td><td>${esc(s.name)}</td><td>${esc(s.department)}</td><td>${s.semester}</td><td>${s.credits}</td><td>${esc(s.faculty || "Not assigned")}</td></tr>`)}</tbody></table></div></div>`;
    $("depForm").onsubmit = e => { e.preventDefault(); post("/api/departments", { name: $("dName").value, code: $("dCode").value }, academics); };
    $("subForm").onsubmit = e => { e.preventDefault(); post("/api/subjects", { code: $("sCode").value, name: $("sName").value, credits: $("sCredits").value,
      semester: $("sSemester").value, department_id: $("sDept").value, faculty_id: $("sFaculty").value }, academics); };
    $("enrollForm").onsubmit = e => { e.preventDefault(); post("/api/students/enroll", { student_id: $("eStudent").value, department_id: $("eDept").value, semester: $("eSemester").value }, academics); };
  }

  async function mark() {
    const subs = (await api("/api/subjects")).data;
    if (!subs.length) { $("view").innerHTML = head("Mark attendance", "") + '<div class="panel"><p class="empty">No subjects are assigned to you yet. Ask your college admin.</p></div>'; return; }
    $("view").innerHTML = head("Mark attendance", "Choose a subject and date, then mark each student.") +
      `<div class="panel"><div class="grid2">
        <div class="field"><label for="mSubject">Subject</label><select id="mSubject">${opts(subs, s => `<option value="${s.id}">${esc(s.code)} · ${esc(s.name)}</option>`)}</select></div>
        <div class="field"><label for="mDate">Date</label><input id="mDate" type="date" value="${today()}" max="${today()}"></div></div>
        <button class="btn" id="mLoad">Load students</button><div id="mArea"></div></div><div id="mReport"></div>`;
    $("mLoad").onclick = loadRoster;
    loadReport();
    $("mSubject").onchange = loadReport;
  }
  async function loadRoster() {
    try {
      const d = (await api(`/api/subjects/${$("mSubject").value}/students?date=${$("mDate").value}`)).data;
      if (!d.students.length) { $("mArea").innerHTML = '<p class="empty">No students are enrolled in this subject yet.</p>'; return; }
      $("mArea").innerHTML = `<div class="tablewrap" style="margin-top:14px"><table><thead><tr><th>Student</th><th>Present</th></tr></thead><tbody>${
        opts(d.students, s => `<tr><td>${esc(s.name)}</td><td><input type="checkbox" id="att-${s.id}" style="width:auto" ${s.present === false ? "" : "checked"} aria-label="Present: ${esc(s.name)}"></td></tr>`)}</tbody></table></div>
        <div class="btnrow"><button class="btn ghost small" id="allP">Mark all present</button><button class="btn ghost small" id="allA">Mark all absent</button>
        <button class="btn" id="mSave">Save attendance</button></div>`;
      $("allP").onclick = () => d.students.forEach(s => $("att-" + s.id).checked = true);
      $("allA").onclick = () => d.students.forEach(s => $("att-" + s.id).checked = false);
      $("mSave").onclick = () => post("/api/attendance", { subject_id: $("mSubject").value, date: $("mDate").value,
        records: d.students.map(s => ({ student_id: s.id, present: $("att-" + s.id).checked })) }, loadReport);
    } catch (e) { toast(e.message, "err"); }
  }
  async function loadReport() {
    try {
      const d = (await api("/api/attendance/subject/" + $("mSubject").value)).data;
      $("mReport").innerHTML = `<div class="panel"><h3>${esc(d.subject.code)} report (minimum ${d.threshold}%)</h3>` + (d.students.length ?
        `<div class="tablewrap"><table><thead><tr><th>Student</th><th>Attended</th><th>%</th><th>Status</th></tr></thead><tbody>${
          opts(d.students, s => `<tr><td>${esc(s.name)}</td><td>${s.attended}/${s.conducted}</td><td>${pct(s)}</td><td>${s.below_threshold ? '<span class="warn">Below minimum</span>' : s.conducted ? "OK" : "No data"}</td></tr>`)}</tbody></table></div>` :
        '<p class="empty">No students enrolled yet.</p>') + "</div>";
    } catch (e) { $("mReport").innerHTML = ""; }
  }

  async function myattendance() {
    const d = (await api("/api/attendance/me")).data, o = d.overall;
    if (!d.subjects.length) { $("view").innerHTML = head("My attendance", "") + '<div class="panel"><p class="empty">You are not enrolled in any subjects yet. Ask your college admin to enroll you.</p></div>'; return; }
    $("view").innerHTML = head("My attendance", `Your college requires ${d.threshold}% in every subject.`) +
      `<div class="stats"><div class="stat"><b>${pct(o)}</b><span>Overall</span></div><div class="stat"><b>${o.conducted}</b><span>Classes held</span></div>
        <div class="stat"><b>${o.attended}</b><span>Attended</span></div><div class="stat"><b>${o.missed}</b><span>Missed</span></div></div>
      <div class="panel"><h3>By subject</h3><div class="tablewrap"><table><thead><tr><th>Subject</th><th>Attended</th><th>%</th><th>What to do</th></tr></thead><tbody>${
        opts(d.subjects, s => `<tr><td>${esc(s.code)} · ${esc(s.name)}</td><td>${s.attended}/${s.conducted}</td><td class="${s.below_threshold ? "warn" : ""}">${pct(s)}</td><td>${nextStep(s, d.threshold)}</td></tr>`)}</tbody></table></div></div>
      <div class="panel"><h3>Recent history</h3>${d.recent.length ? `<div class="tablewrap"><table><tbody>${opts(d.recent, r => `<tr><td>${esc(r.date)}</td><td>${esc(r.subject)}</td><td>${r.present ? '<span class="good">Present</span>' : '<span class="warn">Absent</span>'}</td></tr>`)}</tbody></table></div>` : '<p class="empty">No records yet.</p>'}</div>`;
  }

  async function reports() {
    const subs = (await api("/api/subjects")).data;
    $("view").innerHTML = head("Attendance reports", "Calculated live from marked attendance.") +
      `<div class="panel"><div class="grid2"><div class="field"><label for="rSubject">Subject</label><select id="rSubject"><option value="">All subjects</option>${opts(subs, s => `<option value="${s.id}">${esc(s.code)} · ${esc(s.name)}</option>`)}</select></div></div>
      <a class="btn small" id="rExport" href="/api/attendance/export.csv" style="text-decoration:none;display:inline-block">Export CSV</a></div><div id="rBody"></div>`;
    const run = async () => {
      const q = $("rSubject").value ? "?subject_id=" + $("rSubject").value : "";
      $("rExport").href = "/api/attendance/export.csv" + q;
      const d = (await api("/api/attendance/report" + q)).data;
      $("rBody").innerHTML = `<div class="panel"><h3>By department</h3>${d.departments.length ? `<div class="tablewrap"><table><thead><tr><th>Department</th><th>Attended/held</th><th>%</th></tr></thead><tbody>${
        opts(d.departments, x => `<tr><td>${esc(x.department)}</td><td>${x.attended}/${x.conducted}</td><td>${pct(x)}</td></tr>`)}</tbody></table></div>` : '<p class="empty">No data yet.</p>'}</div>
        <div class="panel"><h3>By subject (minimum ${d.threshold}%)</h3>${d.subjects.length ? `<div class="tablewrap"><table><thead><tr><th>Subject</th><th>Sem</th><th>Faculty</th><th>%</th><th>Students below minimum</th></tr></thead><tbody>${
        opts(d.subjects, x => `<tr><td>${esc(x.code)} · ${esc(x.name)}</td><td>${x.semester}</td><td>${esc(x.faculty || "–")}</td><td>${pct(x)}</td><td>${x.students_below}</td></tr>`)}</tbody></table></div>` : '<p class="empty">No data yet.</p>'}</div>`;
    };
    $("rSubject").onchange = () => run().catch(e => toast(e.message, "err"));
    run().catch(e => toast(e.message, "err"));
  }

  Object.assign(window.EXTRA_VIEWS, { academics, mark, myattendance, reports });
})();
