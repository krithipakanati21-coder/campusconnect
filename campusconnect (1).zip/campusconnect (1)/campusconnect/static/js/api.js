// Shared helpers used by every page. All API calls go through api().
async function api(path, options = {}) {
  const opts = { method: options.method || "GET", headers: { "Content-Type": "application/json" }, credentials: "same-origin" };
  if (options.body !== undefined) opts.body = JSON.stringify(options.body);
  let res, payload;
  try {
    res = await fetch(path, opts);
    payload = await res.json();
  } catch (e) {
    throw new Error("Network problem. Check your connection and try again.");
  }
  if (!payload.success) {
    const err = new Error(payload.message || "Something went wrong.");
    err.status = res.status;
    throw err;
  }
  return payload; // { success, data, message }
}

function esc(value) { // prevents HTML injection when showing user-entered text
  return String(value ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function toast(message, kind = "") {
  let box = document.getElementById("toasts");
  if (!box) { box = document.createElement("div"); box.id = "toasts"; document.body.appendChild(box); }
  const t = document.createElement("div");
  t.className = "toast " + kind;
  t.textContent = message;
  box.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

function fmtDate(iso) {
  return new Date(iso).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}
