// AI assistant (students) + doubts inbox (students and faculty).
(function () {
  window.EXTRA_NAV = window.EXTRA_NAV || {};
  window.EXTRA_VIEWS = window.EXTRA_VIEWS || {};
  const nav = (role, items) => { (window.EXTRA_NAV[role] = window.EXTRA_NAV[role] || []).push(...items); };
  nav("student", [["assistant", "AI assistant"], ["doubts", "My doubts"]]);
  nav("faculty", [["doubts", "Student doubts"]]);
  let ctx = {};
  const lines = s => esc(s).replace(/\n/g, "<br>");

  function addMsg(who, html) {
    const log = $("chatLog"), m = document.createElement("div");
    m.className = "msg " + who; m.innerHTML = html; log.appendChild(m); log.scrollTop = log.scrollHeight; return m;
  }
  function botHtml(r) {
    let h = lines(r.reply);
    if (r.sources.length) h += `<small>Source: ${esc(r.sources.join(", "))}</small>`;
    if (r.handoff) h += r.handoff.faculty.map((f, i) => `<div class="facbox"><b>${esc(f.name)}</b> · ${esc(f.email)}<br><small>${esc(f.why)}</small>
      <div class="btnrow"><button class="btn small" data-draft="${i}">Write a message to ${esc(f.name.split(" ")[0])}</button></div><div data-box="${i}"></div></div>`).join("");
    if (r.suggestions.length) h += `<div class="btnrow">${r.suggestions.map(s => `<button class="chip" data-q="${esc(s)}">${esc(s)}</button>`).join("")}</div>`;
    return h;
  }
  async function send(text) {
    text = text.trim(); if (!text) return;
    addMsg("me", esc(text)); $("chatInput").value = "";
    const wait = addMsg("bot", "Thinking…");
    try {
      const r = (await api("/api/chat", { method: "POST", body: { message: text, context: ctx } })).data;
      ctx = r.context; wait.innerHTML = botHtml(r); wait._r = r;
    } catch (e) { wait.innerHTML = esc(e.message); }
    $("chatLog").scrollTop = $("chatLog").scrollHeight;
  }

  async function assistant() {
    $("view").innerHTML = head("AI assistant", "Ask in your own words. Answers come from your college's records.") +
      `<div class="panel"><div class="chatlog" id="chatLog" aria-live="polite"></div>
        <form class="chatform" id="chatForm"><input id="chatInput" maxlength="500" autocomplete="off" placeholder="e.g. how much attendence do i have in dbms?" aria-label="Your question">
        <button class="btn" id="chatSend" type="submit">Send</button></form></div>`;
    addMsg("bot", botHtml({ reply: `Hi ${me.name.split(" ")[0]}! Ask me about your attendance, subjects, faculty or announcements. If I can't answer, I'll help you reach the right faculty member.`, sources: [], handoff: null, suggestions: ["What's my attendance?", "Which subjects am I enrolled in?", "Latest announcements", "Explain normalization in database"] }));
    $("chatForm").onsubmit = e => { e.preventDefault(); send($("chatInput").value); };
    $("chatLog").onclick = async e => {
      const t = e.target, msgEl = t.closest(".msg");
      if (t.dataset.q) return send(t.dataset.q);
      if (t.dataset.draft !== undefined) {  // step 1: student reviews the draft
        const i = +t.dataset.draft, f = msgEl._r.handoff.faculty[i], box = msgEl.querySelector(`[data-box="${i}"]`);
        box.innerHTML = `<textarea aria-label="Message to ${esc(f.name)}">${esc(msgEl._r.handoff.draft)}</textarea>
          <div class="btnrow"><button class="btn small" data-send="${i}">Send to ${esc(f.name.split(" ")[0])}</button><button class="btn ghost small" data-cancel="${i}">Cancel</button></div>`;
      } else if (t.dataset.cancel !== undefined) {
        msgEl.querySelector(`[data-box="${t.dataset.cancel}"]`).innerHTML = "";
      } else if (t.dataset.send !== undefined) {  // step 2: only sent after explicit approval
        const i = +t.dataset.send, f = msgEl._r.handoff.faculty[i], box = msgEl.querySelector(`[data-box="${i}"]`);
        t.disabled = true;
        try {
          const r = await api("/api/doubts", { method: "POST", body: { faculty_id: f.id, subject_id: f.subject_id, question: box.querySelector("textarea").value } });
          box.innerHTML = `<p class="good">Sent to ${esc(f.name)}. Request #${r.data.id}, status: ${esc(r.data.status)}. Track the reply under "My doubts".</p>`;
        } catch (err) { t.disabled = false; toast(err.message, "err"); }
      }
    };
  }

  async function doubts() {
    const list = (await api("/api/doubts")).data, isFac = me.role === "faculty";
    $("view").innerHTML = head(isFac ? "Student doubts" : "My doubts", isFac ? "Questions sent to you by students." : "Questions you sent to faculty and their replies.") +
      `<div class="panel" id="dList">${list.length ? list.map(d => `<div class="item"><h4>${esc(d.subject)} · ${esc(isFac ? d.student : "to " + d.faculty)}</h4>
        <div class="meta"><span class="tag">${esc(d.status)}</span>${fmtDate(d.created_at)}</div><p>${esc(d.question)}</p>
        ${d.reply ? `<p><b>Reply:</b> ${esc(d.reply)}</p>` : (isFac ? `<textarea id="rep-${d.id}" aria-label="Your reply"></textarea><button class="btn small" data-reply="${d.id}">Send reply</button>` : '<p class="meta">Waiting for a reply.</p>')}</div>`).join("")
        : '<p class="empty">No doubts yet.</p>'}</div>`;
    $("dList").onclick = async e => {
      const id = e.target.dataset.reply; if (!id) return;
      try { toast((await api(`/api/doubts/${id}/reply`, { method: "POST", body: { reply: $("rep-" + id).value } })).message, "good"); doubts(); }
      catch (err) { toast(err.message, "err"); }
    };
  }
  Object.assign(window.EXTRA_VIEWS, { assistant, doubts });
})();
