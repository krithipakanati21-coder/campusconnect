const $ = id => document.getElementById(id);
const ROLE_LABEL = { platform_admin: "Platform administrator", college_admin: "College administrator", student: "Student",
  faculty: "Faculty", placement_officer: "Placement officer", recruiter: "Recruiter" };
const BASE = [["overview", "Overview"], ["announcements", "Announcements"]];
const NAV = { platform_admin: [["overview", "Overview"], ["colleges", "Colleges"]],
  college_admin: [...BASE, ["users", "Users"]], faculty: BASE, placement_officer: BASE, student: BASE, recruiter: BASE };
const CAN_POST = ["college_admin", "faculty", "placement_officer"];
const CATEGORIES = ["general", "academic", "event", "placement", "administrative"];
// Extra menu items/views from other modules (e.g. academics.js) are merged in here.
Object.entries(window.EXTRA_NAV || {}).forEach(([role, items]) => { NAV[role] = [...NAV[role], ...items]; });
let me = null;

async function init() {
  try { me = (await api("/api/auth/me")).data; } catch (e) { location.href = "/login"; return; }
  if (me.college) {
    document.documentElement.style.setProperty("--brand", me.college.primary_color);
    $("collegeName").textContent = me.college.name;
    $("collegeCode").textContent = "Code: " + me.college.code;
  } else { $("collegeName").textContent = "Platform console"; }
  $("userName").textContent = me.name;
  $("userRole").textContent = ROLE_LABEL[me.role];
  $("nav").innerHTML = NAV[me.role].map(([id, label]) => `<button data-view="${id}">${label}</button>`).join("");
  $("nav").addEventListener("click", e => { if (e.target.dataset.view) go(e.target.dataset.view); });
  $("logoutBtn").onclick = async () => { await api("/api/auth/logout", { method: "POST" }); location.href = "/login"; };
  go(location.hash.slice(1));
}

function go(view) {
  const allowed = NAV[me.role].map(n => n[0]);
  if (!allowed.includes(view)) view = "overview";
  location.hash = view;
  document.querySelectorAll("#nav button").forEach(b => b.classList.toggle("active", b.dataset.view === view));
  $("view").innerHTML = '<p class="empty">Loading…</p>';
  ({ overview, announcements, users, colleges, ...(window.EXTRA_VIEWS || {}) })[view]().catch(err => {
    if (err.status === 401) location.href = "/login";
    $("view").innerHTML = `<p class="error">${esc(err.message)}</p>`;
  });
}

function head(title, sub) { return `<div class="head"><h1>${esc(title)}</h1><p class="sub">${esc(sub)}</p></div>`; }
function annItem(a, canDelete) {
  const del = canDelete ? `<button class="btn danger small" data-del="${a.id}">Delete</button>` : "";
  return `<div class="item"><h4>${esc(a.title)}</h4>
    <div class="meta"><span class="tag">${esc(a.category)}</span>${esc(a.author)} · ${fmtDate(a.created_at)}</div>
    <p>${esc(a.body)}</p>${del}</div>`;
}
const stat = (n, label) => `<div class="stat"><b>${n}</b><span>${label}</span></div>`;

async function overview() {
  const d = (await api("/api/dashboard")).data;
  const first = me.name.split(" ")[0];
  let stats = "";
  if (me.role === "platform_admin") stats = stat(d.colleges, "Colleges") + stat(d.users, "Total users");
  else {
    stats = stat(d.announcements, "Announcements");
    if (me.role === "college_admin") stats += stat(d.students, "Students") + stat(d.facultys, "Faculty") + stat(d.placement_officers, "Placement officers") + stat(d.recruiters, "Recruiters");
  }
  const latest = d.latest ? `<div class="panel"><h3>Latest announcements</h3>${
    d.latest.length ? d.latest.map(a => annItem(a, false)).join("") : '<p class="empty">No announcements yet.</p>'}</div>` : "";
  $("view").innerHTML = head(`Hello, ${first}`, ROLE_LABEL[me.role] + (me.college ? " at " + me.college.name : "")) +
    `<div class="stats">${stats}</div>${latest}`;
}

async function announcements() {
  const list = (await api("/api/announcements")).data;
  const canPost = CAN_POST.includes(me.role);
  const form = canPost ? `<div class="panel"><h3>New announcement</h3><form id="annForm">
    <div class="field"><label for="annTitle">Title</label><input id="annTitle" name="title" maxlength="150" required></div>
    <div class="field"><label for="annCategory">Category</label><select id="annCategory" name="category">
      ${CATEGORIES.map(c => `<option value="${c}">${c}</option>`).join("")}</select></div>
    <div class="field"><label for="annBody">Message</label><textarea id="annBody" name="body" required></textarea></div>
    <button class="btn" type="submit">Publish announcement</button></form></div>` : "";
  const canDel = a => me.role === "college_admin" || (canPost && a.author_id === me.id);
  $("view").innerHTML = head("Announcements", "Updates from your college.") + form +
    `<div class="panel" id="annList">${list.length ? list.map(a => annItem(a, canDel(a))).join("") : '<p class="empty">No announcements yet.</p>'}</div>`;
  if (canPost) $("annForm").onsubmit = async e => {
    e.preventDefault();
    try {
      await api("/api/announcements", { method: "POST", body: { title: $("annTitle").value, category: $("annCategory").value, body: $("annBody").value } });
      toast("Published.", "good"); announcements();
    } catch (err) { toast(err.message, "err"); }
  };
  $("annList").onclick = async e => {
    const id = e.target.dataset.del; if (!id || !confirm("Delete this announcement?")) return;
    try { await api("/api/announcements/" + id, { method: "DELETE" }); toast("Deleted.", "good"); announcements(); }
    catch (err) { toast(err.message, "err"); }
  };
}

async function users() {
  const list = (await api("/api/users")).data;
  const rows = list.map(u => `<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${ROLE_LABEL[u.role]}</td>
    <td>${u.is_active ? "Active" : '<span class="off">Inactive</span>'}</td>
    <td>${u.id === me.id ? "" : `<button class="btn ghost small" data-toggle="${u.id}">${u.is_active ? "Deactivate" : "Activate"}</button>`}</td></tr>`).join("");
  $("view").innerHTML = head("Users", "Add and manage people in your college.") + `<div class="panel"><h3>Add a user</h3>
    <form id="userForm"><div class="grid2">
      <div class="field"><label for="uName">Full name</label><input id="uName" name="name" required></div>
      <div class="field"><label for="uEmail">Email</label><input id="uEmail" name="email" type="email" required></div>
      <div class="field"><label for="uRole">Role</label><select id="uRole" name="role">
        ${["student", "faculty", "placement_officer", "recruiter", "college_admin"].map(r => `<option value="${r}">${ROLE_LABEL[r]}</option>`).join("")}</select></div>
      <div class="field"><label for="uPassword">Temporary password (8+ characters)</label><input id="uPassword" name="password" type="password" minlength="8" required></div>
    </div><button class="btn" type="submit">Add user</button></form></div>
    <div class="panel"><h3>People (${list.length})</h3><div class="tablewrap"><table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th></th></tr></thead><tbody id="userRows">${rows}</tbody></table></div></div>`;
  $("userForm").onsubmit = async e => {
    e.preventDefault();
    try {
      const r = await api("/api/users", { method: "POST", body: { name: $("uName").value, email: $("uEmail").value, role: $("uRole").value, password: $("uPassword").value } });
      toast(r.message, "good"); users();
    } catch (err) { toast(err.message, "err"); }
  };
  $("userRows").onclick = async e => {
    const id = e.target.dataset.toggle; if (!id) return;
    try { toast((await api(`/api/users/${id}/toggle`, { method: "POST" })).message, "good"); users(); }
    catch (err) { toast(err.message, "err"); }
  };
}

async function colleges() {
  const list = (await api("/api/colleges")).data;
  const rows = list.map(c => `<tr><td><span class="swatch" style="background:${esc(c.primary_color)}"></span>${esc(c.name)}</td>
    <td>${esc(c.code)}</td><td>${c.users}</td><td>${c.is_demo ? "Sample" : "Live"}</td><td>${fmtDate(c.created_at)}</td></tr>`).join("");
  $("view").innerHTML = head("Colleges", "Create and review college tenants.") + `<div class="panel"><h3>Create a college</h3>
    <form id="collegeForm"><div class="grid2">
      <div class="field"><label for="cName">College name</label><input id="cName" name="name" required></div>
      <div class="field"><label for="cCode">College code (letters/numbers)</label><input id="cCode" name="code" maxlength="20" required></div>
      <div class="field"><label for="cColor">Brand color</label><input id="cColor" name="primary_color" type="color" value="#3b4cca"></div>
      <div class="field"><label for="cAdminName">Admin name</label><input id="cAdminName" name="admin_name" required></div>
      <div class="field"><label for="cAdminEmail">Admin email</label><input id="cAdminEmail" name="admin_email" type="email" required></div>
      <div class="field"><label for="cAdminPassword">Admin password (8+ characters)</label><input id="cAdminPassword" name="admin_password" type="password" minlength="8" required></div>
    </div><button class="btn" type="submit">Create college</button></form></div>
    <div class="panel"><h3>All colleges (${list.length})</h3><div class="tablewrap"><table><thead><tr><th>College</th><th>Code</th><th>Users</th><th>Type</th><th>Created</th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
  $("collegeForm").onsubmit = async e => {
    e.preventDefault();
    try {
      const r = await api("/api/colleges", { method: "POST", body: { name: $("cName").value, code: $("cCode").value, primary_color: $("cColor").value,
        admin_name: $("cAdminName").value, admin_email: $("cAdminEmail").value, admin_password: $("cAdminPassword").value } });
      toast(r.message, "good"); colleges();
    } catch (err) { toast(err.message, "err"); }
  };
}

init();
