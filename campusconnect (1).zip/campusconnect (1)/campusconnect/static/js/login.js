const $ = id => document.getElementById(id);

const DEMOS = [
  ["Student", "DEMO", "student@demo.edu", "Demo@12345"],
  ["Faculty", "DEMO", "faculty@demo.edu", "Demo@12345"],
  ["Placement officer", "DEMO", "placement@demo.edu", "Demo@12345"],
  ["College admin", "DEMO", "admin@demo.edu", "Demo@12345"],
  ["Other college admin", "RIVER", "admin@river.edu", "Demo@12345"],
  ["Platform admin", "", "admin@campusconnect.local", "Admin@12345"],
];

DEMOS.forEach(([label, code, email, pw]) => {
  const b = document.createElement("button");
  b.type = "button"; b.className = "chip"; b.textContent = label;
  b.onclick = () => { $("collegeCode").value = code; $("email").value = email; $("password").value = pw; };
  $("demoChips").appendChild(b);
});

$("loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  $("loginError").textContent = "";
  $("loginBtn").disabled = true; $("loginBtn").textContent = "Logging in…";
  try {
    await api("/api/auth/login", { method: "POST", body: {
      college_code: $("collegeCode").value, email: $("email").value, password: $("password").value } });
    location.href = "/dashboard";
  } catch (err) {
    $("loginError").textContent = err.message;
    $("loginBtn").disabled = false; $("loginBtn").textContent = "Log in";
  }
});
