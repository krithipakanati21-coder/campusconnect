"""Run with:  python -m unittest discover -s tests -v"""
import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import create_app


class CampusConnectTests(unittest.TestCase):
    def setUp(self):
        self.app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:"})

    def login(self, code, email, pw="Demo@12345"):
        c = self.app.test_client()
        r = c.post("/api/auth/login", json={"college_code": code, "email": email, "password": pw})
        return c, r

    def test_login_success_and_failure(self):
        c, r = self.login("DEMO", "student@demo.edu")
        self.assertEqual(r.status_code, 200); self.assertTrue(r.json["success"])
        _, bad = self.login("DEMO", "student@demo.edu", "wrong")
        self.assertEqual(bad.status_code, 401)

    def test_wrong_college_code_cannot_login(self):
        _, r = self.login("RIVER", "student@demo.edu")
        self.assertEqual(r.status_code, 401)

    def test_api_requires_login_and_returns_json(self):
        r = self.app.test_client().get("/api/announcements")
        self.assertEqual(r.status_code, 401); self.assertFalse(r.json["success"])

    def test_student_cannot_post_or_list_users(self):
        c, _ = self.login("DEMO", "student@demo.edu")
        self.assertEqual(c.post("/api/announcements", json={"title": "x", "body": "y"}).status_code, 403)
        self.assertEqual(c.get("/api/users").status_code, 403)

    def test_faculty_can_post_and_students_see_it(self):
        f, _ = self.login("DEMO", "faculty@demo.edu")
        self.assertEqual(f.post("/api/announcements", json={"title": "Notes up", "body": "Unit 1", "category": "academic"}).status_code, 201)
        s, _ = self.login("DEMO", "student@demo.edu")
        self.assertIn("Notes up", [a["title"] for a in s.get("/api/announcements").json["data"]])

    def test_tenant_isolation(self):
        d, _ = self.login("DEMO", "admin@demo.edu")
        r, _ = self.login("RIVER", "admin@river.edu")
        d.post("/api/announcements", json={"title": "DEMO-ONLY", "body": "secret"})
        self.assertNotIn("DEMO-ONLY", [a["title"] for a in r.get("/api/announcements").json["data"]])
        demo_ann = d.get("/api/announcements").json["data"][0]["id"]
        self.assertEqual(r.delete(f"/api/announcements/{demo_ann}").status_code, 404)
        demo_users = d.get("/api/users").json["data"]
        self.assertEqual(r.post(f"/api/users/{demo_users[0]['id']}/toggle").status_code, 404)
        river_id = r.get("/api/auth/me").json["data"]["college_id"]
        self.assertTrue(all(u["college_id"] == river_id for u in r.get("/api/users").json["data"]))

    def test_platform_admin_creates_college_and_new_admin_logs_in(self):
        p, r = self.login("", "admin@campusconnect.local", "Admin@12345")
        self.assertEqual(r.status_code, 200)
        r = p.post("/api/colleges", json={"name": "New College", "code": "new1", "primary_color": "#112233",
                   "admin_name": "Ann", "admin_email": "ann@new.edu", "admin_password": "Password1"})
        self.assertEqual(r.status_code, 201)
        _, r = self.login("NEW1", "ann@new.edu", "Password1")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(p.post("/api/colleges", json={"name": "Dup", "code": "NEW1", "admin_name": "A",
                         "admin_email": "a@b.co", "admin_password": "Password1"}).status_code, 409)

    def test_college_admin_cannot_create_colleges(self):
        c, _ = self.login("DEMO", "admin@demo.edu")
        self.assertEqual(c.post("/api/colleges", json={}).status_code, 403)

    def test_deactivated_user_is_locked_out(self):
        a, _ = self.login("DEMO", "admin@demo.edu")
        sid = next(u["id"] for u in a.get("/api/users").json["data"] if u["email"] == "student@demo.edu")
        s, _ = self.login("DEMO", "student@demo.edu")
        a.post(f"/api/users/{sid}/toggle")
        self.assertEqual(s.get("/api/auth/me").status_code, 401)


if __name__ == "__main__":
    unittest.main()
