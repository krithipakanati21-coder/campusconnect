"""Module 2 + assistant tests.  Run: python -m unittest discover -s tests -v"""
import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import create_app
from academics import summarize


class Base(unittest.TestCase):
    def setUp(self):
        self.app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:"})

    def login(self, code, email):
        c = self.app.test_client()
        self.assertEqual(c.post("/api/auth/login", json={"college_code": code, "email": email, "password": "Demo@12345"}).status_code, 200)
        return c


class AttendanceTests(Base):
    def test_math(self):
        self.assertEqual(summarize(10, 20, 75)["classes_needed"], 20)   # (10+20)/(20+20) = 75%
        self.assertEqual(summarize(18, 20, 75)["can_miss"], 4)           # 18/24 = 75%
        self.assertEqual(summarize(0, 0, 75)["percentage"], None)

    def test_marking_no_duplicates_and_student_view(self):
        f = self.login("DEMO", "faculty@demo.edu")
        sub = f.get("/api/subjects").json["data"][0]
        studs = f.get(f"/api/subjects/{sub['id']}/students?date=2020-01-06").json["data"]["students"]
        recs = [{"student_id": s["id"], "present": True} for s in studs]
        self.assertEqual(f.post("/api/attendance", json={"subject_id": sub["id"], "date": "2020-01-06", "records": recs}).status_code, 200)
        before = f.get(f"/api/attendance/subject/{sub['id']}").json["data"]["students"]
        recs[0]["present"] = False  # edit same day: must update, not duplicate
        f.post("/api/attendance", json={"subject_id": sub["id"], "date": "2020-01-06", "records": recs})
        after = f.get(f"/api/attendance/subject/{sub['id']}").json["data"]["students"]
        self.assertEqual(before[0]["conducted"], after[0]["conducted"])
        self.assertEqual(before[0]["attended"] - 1, after[0]["attended"])
        s = self.login("DEMO", "student@demo.edu").get("/api/attendance/me").json["data"]
        self.assertEqual(s["overall"]["conducted"], sum(r["conducted"] for r in s["subjects"]))

    def test_permissions_and_validation(self):
        st = self.login("DEMO", "student@demo.edu")
        self.assertEqual(st.post("/api/attendance", json={}).status_code, 403)
        f = self.login("DEMO", "faculty@demo.edu")
        sub = f.get("/api/subjects").json["data"][0]
        self.assertEqual(f.post("/api/attendance", json={"subject_id": sub["id"], "date": "2999-01-01", "records": [{"student_id": 1, "present": True}]}).status_code, 400)
        other = self.login("RIVER", "faculty@river.edu")
        self.assertEqual(other.get(f"/api/subjects/{sub['id']}/students").status_code, 404)
        self.assertEqual(other.post("/api/attendance", json={"subject_id": sub["id"], "date": "2020-01-06", "records": []}).status_code, 404)

    def test_admin_report_isolated_and_csv(self):
        a = self.login("DEMO", "admin@demo.edu")
        self.assertEqual(a.get("/api/attendance/report").status_code, 200)
        r = a.get("/api/attendance/export.csv")
        self.assertIn("text/csv", r.content_type); self.assertIn("Sample Student", r.get_data(as_text=True))
        self.assertEqual(self.login("DEMO", "student@demo.edu").get("/api/attendance/report").status_code, 403)


class ChatTests(Base):
    def ask(self, c, msg, ctx=None):
        return c.post("/api/chat", json={"message": msg, "context": ctx or {}}).json["data"]

    def test_understands_typos_slang_and_followups(self):
        c = self.login("DEMO", "student@demo.edu")
        r = self.ask(c, "hw much attendnce do i hav")
        self.assertEqual(r["intent"], "attendance"); self.assertIn("overall attendance", r["reply"])
        r = self.ask(c, "attendence in dbms??")
        self.assertEqual(r["intent"], "attendance"); self.assertIn("CS102", r["reply"])
        r2 = self.ask(c, "and python?", r["context"])           # follow-up reuses 'attendance'
        self.assertEqual(r2["intent"], "attendance"); self.assertIn("CS101", r2["reply"])
        r3 = self.ask(c, "who teaches it", self.ask(c, "attendance in networks")["context"])
        self.assertEqual(r3["intent"], "faculty_who"); self.assertIn("CS103", r3["reply"])

    def test_numbers_match_database(self):
        c = self.login("DEMO", "student@demo.edu")
        d = c.get("/api/attendance/me").json["data"]["overall"]
        self.assertIn(f"{d['percentage']}%", self.ask(c, "what's my attendance")["reply"])

    def test_unknown_question_hands_off_to_faculty_and_requires_approval(self):
        c = self.login("DEMO", "student@demo.edu")
        r = self.ask(c, "can you explain normalization in database")
        self.assertIsNone(r["intent"]); self.assertEqual(r["handoff"]["faculty"][0]["name"], "Dr. Sample Faculty")
        self.assertIn("CS102", r["handoff"]["faculty"][0]["why"])
        self.assertEqual(c.get("/api/doubts").json["data"], [])      # nothing created until approved
        f = r["handoff"]["faculty"][0]
        p = c.post("/api/doubts", json={"faculty_id": f["id"], "subject_id": f["subject_id"], "question": r["handoff"]["draft"]})
        self.assertEqual(p.status_code, 201)
        fac = self.login("DEMO", "faculty@demo.edu")
        did = fac.get("/api/doubts").json["data"][0]["id"]
        self.assertEqual(fac.post(f"/api/doubts/{did}/reply", json={"reply": "See unit 2."}).status_code, 200)
        self.assertEqual(c.get("/api/doubts").json["data"][0]["status"], "answered")

    def test_doubt_security(self):
        c = self.login("DEMO", "student@demo.edu")
        self.assertEqual(c.post("/api/doubts", json={"faculty_id": 1, "subject_id": 1, "question": "hello there"}).status_code, 400)
        fac = self.login("DEMO", "faculty@demo.edu")
        self.assertEqual(fac.post("/api/chat", json={"message": "hi"}).status_code, 403)
        c.post("/api/doubts", json={"faculty_id": fac.get("/api/auth/me").json["data"]["id"], "subject_id": fac.get("/api/subjects").json["data"][0]["id"], "question": "my question"})
        self.assertEqual(self.login("RIVER", "faculty@river.edu").get("/api/doubts").json["data"], [])

    def test_vague_and_placement(self):
        c = self.login("DEMO", "student@demo.edu")
        self.assertIn("more", self.ask(c, "hmm")["reply"])
        self.assertIn("placement", self.ask(c, "any jobs for me?")["reply"].lower())


if __name__ == "__main__":
    unittest.main()
